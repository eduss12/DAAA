//
//  Autor.swift
//  entrega1
//
//  Created by Eduardo Sáez Santero on 8/11/2024.
//

import Foundation
import SwiftData

@Model
class Autor {
    var nombre: String
    var apellidos: String

    init(nombre: String, apellidos: String) {
        self.nombre = nombre
        self.apellidos = apellidos
    }
}

